# Scrollbox

A lightweight jQuery custom scrollbar plugin, that triggers event when reached the defined point.

## Usage

See [index.html](https://github.com/Invis1ble/scrollbox/blob/master/index.html) for the basic usage.
(will be documented later)

## API documentation

(will be documented later)

## License

[MIT](http://www.opensource.org/licenses/mit-license.php)